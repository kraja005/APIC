# ----------------------------------------------------------------------
# Script: Deploy-APIC-Product.ps1
# Description: Logs in to IBM API Connect and publishes a product.
# ----------------------------------------------------------------------

# --- Configuration Variables ---

# Replace with your specific API Connect environment details
$ManagerHost = "api-manager.a-vir-c1.apiconnect.ipaas.automation.ibm.com"
$ProviderOrg = "dev7180018"
$Catalog     = "sandbox"
$ProductFile = "testproduct.yaml"
$APIKey = "71f5145b-a386-495e-8bd8-b3e30fc378ba"

# --- Credentials ---

# NOTE: For security, DO NOT hardcode your API Key here.
# It is best practice to pass this as an argument or read it securely.
# For direct VDI use, you will be prompted for it.
#$APIKey = Read-Host -Prompt "Enter your API Connect API Key"

# --- Deployment Logic ---

Write-Host "--- Starting APIC Deployment ---"
Write-Host "Target Host: $ManagerHost"
Write-Host "Target Catalog: $Catalog"

# 1. Log in to the APIC Manager
Write-Host "Attempting APIC Login..."
apic login `
    --apikey $APIKey `
    --server $ManagerHost `
    --context provider `
    --scope org `
    --org $ProviderOrg

# Check if the login command was successful
if ($LASTEXITCODE -ne 0) {
    Write-Error "APIC Login failed (Exit Code: $LASTEXITCODE). Check your API Key and host."
    exit 1
}
Write-Host "Login successful."

# 2. Publish the Product
Write-Host "Publishing product '$ProductFile'..."

# The 'apic publish' command stages and publishes the product
apic publish $ProductFile `
    --server $ManagerHost `
    --org $ProviderOrg `
    --catalog $Catalog `
    --stage

# Check if the publish command was successful
if ($LASTEXITCODE -eq 0) {
    Write-Host "--- Deployment Complete ---"
    Write-Host "Product '$ProductFile' deployed successfully to '$Catalog'."
    exit 0
} else {
    Write-Error "APIC Publish failed (Exit Code: $LASTEXITCODE). Check logs and product file contents."
    exit 1
}
